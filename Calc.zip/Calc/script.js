function numCatch(a) {
    let inp=document.getElementById('input1');
    inp.value=inp.value+a.value;
}
function barobar() {
    let r=document.getElementById('input1');
    r.value=eval(r.value);
}
function reset() {
    let res=document.getElementById('input1');
    res.value="";
}